import tkinter as tk
from tkinter import colorchooser, filedialog, messagebox
from PIL import Image, ImageDraw, ImageGrab

class PaintApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Twój pędzel")
        self.root.geometry("800x600")
        self.color = "black"
        self.last_x, self.last_y = None, None

        self.canvas = tk.Canvas(self.root, bg="white", width=800, height=500)
        self.canvas.pack(pady=10)

        btn_frame = tk.Frame(self.root)
        btn_frame.pack()

        tk.Button(btn_frame, text="Kolor", command=self.choose_color).pack(side=tk.LEFT, padx=5)
        tk.Button(btn_frame, text="Wyczyść", command=self.clear_canvas).pack(side=tk.LEFT, padx=5)
        tk.Button(btn_frame, text="Zapisz", command=self.save_image).pack(side=tk.LEFT, padx=5)

        self.canvas.bind("<B1-Motion>", self.paint)
        self.canvas.bind("<ButtonRelease-1>", self.reset)

    def choose_color(self):
        color = colorchooser.askcolor()[1]
        if color:
            self.color = color

    def paint(self, event):
        if self.last_x and self.last_y:
            self.canvas.create_line(self.last_x, self.last_y, event.x, event.y, fill=self.color, width=3, capstyle=tk.ROUND, smooth=True)
        self.last_x, self.last_y = event.x, event.y

    def reset(self, event):
        self.last_x, self.last_y = None, None

    def clear_canvas(self):
        self.canvas.delete("all")

    def save_image(self):
        filetypes = [
            ("PNG", "*.png"),
            ("JPG", "*.jpg"),
            ("JPEG", "*.jpeg"),
            ("Bitmap", "*.bmp"),
        ]
        file = filedialog.asksaveasfilename(defaultextension=".png", filetypes=filetypes)
        if file:
            # Pobierz pozycję canvasa na ekranie
            x = self.root.winfo_rootx() + self.canvas.winfo_x()
            y = self.root.winfo_rooty() + self.canvas.winfo_y()
            x1 = x + self.canvas.winfo_width()
            y1 = y + self.canvas.winfo_height()
            # Zrób zrzut ekranu obszaru canvasa
            img = ImageGrab.grab().crop((x, y, x1, y1))
            try:
                img.save(file)
                messagebox.showinfo("Zapisano", f"Obraz zapisany jako {file}")
            except Exception as e:
                messagebox.showerror("Błąd", f"Nie udało się zapisać: {e}")

if __name__ == "__main__":
    root = tk.Tk()
    app = PaintApp(root)
    root.mainloop()