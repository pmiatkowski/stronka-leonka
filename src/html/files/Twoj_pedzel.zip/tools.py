class Pencil:
    def __init__(self, color='black', width=1):
        self.color = color
        self.width = width

    def draw(self, canvas, start_x, start_y, end_x, end_y):
        canvas.create_line(start_x, start_y, end_x, end_y, fill=self.color, width=self.width)


class Eraser:
    def __init__(self, width=10):
        self.width = width

    def erase(self, canvas, start_x, start_y, end_x, end_y):
        canvas.create_rectangle(start_x, start_y, end_x, end_y, fill='white', outline='white')


class Rectangle:
    def __init__(self, color='black', width=1):
        self.color = color
        self.width = width

    def draw(self, canvas, start_x, start_y, end_x, end_y):
        canvas.create_rectangle(start_x, start_y, end_x, end_y, outline=self.color, width=self.width)