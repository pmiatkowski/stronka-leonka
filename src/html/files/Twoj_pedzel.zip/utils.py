def save_image(canvas, filename, file_format):
    from PIL import Image

    # Get the canvas size
    width = canvas.winfo_width()
    height = canvas.winfo_height()

    # Create a new image with the same size as the canvas
    image = Image.new("RGB", (width, height), "white")

    # Render the canvas to the image
    canvas.postscript(file="temp.ps", colormode='color')
    img = Image.open("temp.ps")
    img.save(filename, format=file_format)

def ask_save_file():
    from tkinter import filedialog

    file_path = filedialog.asksaveasfilename(defaultextension=".png",
                                               filetypes=[("PNG files", "*.png"),
                                                          ("JPEG files", "*.jpg;*.jpeg"),
                                                          ("Bitmap files", "*.bmp"),
                                                          ("JPG files", "*.jpg"),
                                                          ("All files", "*.*")])
    return file_path if file_path else None

def save_drawing(canvas):
    file_path = ask_save_file()
    if file_path:
        file_format = file_path.split('.')[-1].upper()
        save_image(canvas, file_path, file_format)