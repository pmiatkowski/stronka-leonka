class Canvas:
    def __init__(self, master, width=800, height=600):
        self.master = master
        self.width = width
        self.height = height
        self.canvas = None
        self.current_tool = None
        self.shapes = []
        self.setup_canvas()

    def setup_canvas(self):
        self.canvas = Canvas(self.master, width=self.width, height=self.height)
        self.canvas.pack()
        self.canvas.bind("<Button-1>", self.on_button_press)
        self.canvas.bind("<B1-Motion>", self.on_mouse_drag)
        self.canvas.bind("<ButtonRelease-1>", self.on_button_release)

    def on_button_press(self, event):
        if self.current_tool:
            self.current_tool.on_button_press(event)

    def on_mouse_drag(self, event):
        if self.current_tool:
            self.current_tool.on_mouse_drag(event)

    def on_button_release(self, event):
        if self.current_tool:
            self.current_tool.on_button_release(event)

    def set_tool(self, tool):
        self.current_tool = tool

    def clear(self):
        self.canvas.delete("all")
        self.shapes.clear()

    def save(self, filename):
        self.canvas.postscript(file=filename + '.eps')
        # Additional code to convert .eps to other formats can be added here.