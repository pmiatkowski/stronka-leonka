
import pygame
import random
import sys
import sqlite3

# Stałe
display_width = 900
display_height = 600
FPS = 60
SAMOLOT_SIZE = (60, 60)
LOTNISKO_SIZE = (100, 100)


# Inicjalizacja Pygame
pygame.init()
clock = pygame.time.Clock()
screen = pygame.display.set_mode((display_width, display_height))
pygame.display.set_caption("Wypatrywanie samolotów")



# Dźwięki: erroru, powodzenia i poziomów
try:
    error_sound = pygame.mixer.Sound("error.wav")
except:
    error_sound = None
try:
    good_sound = pygame.mixer.Sound("good.wav")
except:
    good_sound = None
try:
    levelup_sound = pygame.mixer.Sound("windows-xp-startup.wav")
except:
    levelup_sound = None

try:
    end_of_level_sound = pygame.mixer.Sound("end_of_level.wav")
except:
    end_of_level_sound = None
try:
    winner_sound = pygame.mixer.Sound("winner.wav")
except:
    winner_sound = None


# Wczytaj obrazy
samolot_img = pygame.image.load("9121335.jpg")
samolot_img = pygame.transform.scale(samolot_img, SAMOLOT_SIZE)
lotnisko_img = pygame.image.load("42374.jpg")
lotnisko_img = pygame.transform.scale(lotnisko_img, LOTNISKO_SIZE)

# Pozycja lotniska
lotnisko_pos = (display_width // 2 - LOTNISKO_SIZE[0] // 2, display_height - LOTNISKO_SIZE[1] - 10)

# Klasa samolotu

# Klasa samolotu
import math
class Samolot:
    def __init__(self):
        # Start z lotniska (środek lotniska)
        self.x = lotnisko_pos[0] + LOTNISKO_SIZE[0] // 2 - SAMOLOT_SIZE[0] // 2
        self.y = lotnisko_pos[1] + LOTNISKO_SIZE[1] // 2 - SAMOLOT_SIZE[1] // 2
        self.speed = random.uniform(1.5, 3.0)
        angle = random.uniform(-math.pi/2 - 0.7, -math.pi/2 + 0.7)  # losowy kąt "w górę"
        self.dx = math.cos(angle) * self.speed
        self.dy = math.sin(angle) * self.speed
        self.rect = pygame.Rect(self.x, self.y, SAMOLOT_SIZE[0], SAMOLOT_SIZE[1])
        self.bezpieczny = random.choice([True, False])
    def update(self):
        self.x += self.dx
        self.y += self.dy
        # Jeśli samolot wyleci poza ekran, pojawia się nowy
        if (self.x < -SAMOLOT_SIZE[0] or self.x > display_width or
            self.y < -SAMOLOT_SIZE[1] or self.y > display_height):
            self.__init__()
        self.rect.topleft = (self.x, self.y)
    def draw(self, surface):
        surface.blit(samolot_img, (self.x, self.y))

def init_db():
    conn = sqlite3.connect("ranking.db")
    c = conn.cursor()
    c.execute("""
        CREATE TABLE IF NOT EXISTS ranking (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            score INTEGER NOT NULL,
            date TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    """)
    conn.commit()
    conn.close()

def add_score(name, score):
    conn = sqlite3.connect("ranking.db")
    c = conn.cursor()
    c.execute("INSERT INTO ranking (name, score) VALUES (?, ?)", (name, score))
    conn.commit()
    conn.close()

def get_top_scores(limit=10):
    conn = sqlite3.connect("ranking.db")
    c = conn.cursor()
    c.execute("SELECT name, score, date FROM ranking ORDER BY score DESC, date ASC LIMIT ?", (limit,))
    results = c.fetchall()
    conn.close()
    return results

def main():
    init_db()
    punkty = 0
    # Liczba samolotów zależna od poziomu
    def liczba_samolotow(punkty):
        if punkty < 100:
            return 5
        elif punkty < 500:
            return 10
        else:
            return 20

    samoloty = [Samolot() for _ in range(liczba_samolotow(0))]
    font = pygame.font.SysFont(None, 32)
    opis_font = pygame.font.SysFont(None, 28)
    big_font = pygame.font.SysFont(None, 60)
    running = True
    level_50_shown = False
    level_100_shown = False
    wygrana = False
    show_50_time = 0
    show_100_time = 0
    winner_sound_played = False
    name_input = ""
    ranking_saved = False
    while running:
        # Ekran wygranej i ranking przy 200 pkt
        if wygrana:
            if not winner_sound_played and winner_sound:
                winner_sound.play()
                winner_sound_played = True
            elif not winner_sound_played and end_of_level_sound:
                end_of_level_sound.play()
                winner_sound_played = True
            screen.fill((200, 255, 200))
            win_text = big_font.render("Wygrałeś!", True, (0, 120, 0))
            screen.blit(win_text, (display_width//2 - win_text.get_width()//2, 30))

            # Wyświetl ranking zawsze
            top_scores = get_top_scores()
            rank_title = font.render("Ranking najlepszych graczy:", True, (0, 0, 120))
            screen.blit(rank_title, (display_width//2 - rank_title.get_width()//2, 90))
            for idx, (n, s, d) in enumerate(top_scores):
                entry = font.render(f"{idx+1}. {n} - {s} pkt", True, (0,0,0))
                screen.blit(entry, (display_width//2 - 120, 130 + idx*35))

            # Pole do wpisania imienia zawsze pod rankingiem
            if not ranking_saved:
                prompt = font.render("Wpisz swoje imię i naciśnij Enter: ", True, (0, 0, 0))
                screen.blit(prompt, (display_width//2 - prompt.get_width()//2, 130 + len(top_scores)*35 + 10))
                input_box = pygame.Rect(display_width//2 - 100, 170 + len(top_scores)*35, 200, 40)
                pygame.draw.rect(screen, (255,255,255), input_box, 0)
                pygame.draw.rect(screen, (0,0,0), input_box, 2)
                name_surf = font.render(name_input, True, (0,0,0))
                screen.blit(name_surf, (input_box.x+10, input_box.y+5))
            else:
                # Po zapisaniu imienia odśwież ranking (już wyświetlony powyżej)
                pass

            # Przycisk nowej gry
            btn_rect = pygame.Rect(display_width//2 - 100, display_height - 100, 200, 60)
            pygame.draw.rect(screen, (80, 180, 80), btn_rect)
            btn_text = font.render("Nowa gra", True, (255,255,255))
            screen.blit(btn_text, (btn_rect.x + 30, btn_rect.y + 15))

            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    running = False
                if not ranking_saved:
                    if event.type == pygame.KEYDOWN:
                        if event.key == pygame.K_RETURN and name_input.strip():
                            add_score(name_input.strip(), punkty)
                            ranking_saved = True
                        elif event.key == pygame.K_BACKSPACE:
                            name_input = name_input[:-1]
                        elif len(name_input) < 16 and event.unicode.isprintable():
                            name_input += event.unicode
                if event.type == pygame.MOUSEBUTTONDOWN:
                    mx, my = pygame.mouse.get_pos()
                    if btn_rect.collidepoint(mx, my):
                        punkty = 0
                        samoloty = [Samolot() for _ in range(3)]
                        level_50_shown = False
                        level_100_shown = False
                        wygrana = False
                        show_50_time = 0
                        show_100_time = 0
                        winner_sound_played = False
                        name_input = ""
                        ranking_saved = False
            pygame.display.flip()
            clock.tick(FPS)
            continue
        # Poziom 50 punktów - komunikat na 3 sekundy
        if punkty >= 50 and not level_50_shown:
            show_50_time = pygame.time.get_ticks()
            level_50_shown = True
            if end_of_level_sound:
                end_of_level_sound.play()
        if level_50_shown and show_50_time > 0:
            elapsed = (pygame.time.get_ticks() - show_50_time) / 1000
            if elapsed < 3:
                screen.fill((255,255,200))
                msg = big_font.render("Dobrze ci idzie", True, (0, 120, 0))
                screen.blit(msg, (display_width//2 - msg.get_width()//2, display_height//2 - 40))
                pygame.display.flip()
                for event in pygame.event.get():
                    if event.type == pygame.QUIT:
                        running = False
                clock.tick(FPS)
                continue
            else:
                show_50_time = 0

        # Poziom 100 punktów - komunikat na 3 sekundy
        if punkty >= 100 and not level_100_shown:
            show_100_time = pygame.time.get_ticks()
            level_100_shown = True
            if end_of_level_sound:
                end_of_level_sound.play()
        if level_100_shown and show_100_time > 0:
            elapsed = (pygame.time.get_ticks() - show_100_time) / 1000
            if elapsed < 3:
                screen.fill((255,255,200))
                msg = big_font.render("Mistrz!", True, (0, 120, 0))
                screen.blit(msg, (display_width//2 - msg.get_width()//2, display_height//2 - 40))
                pygame.display.flip()
                for event in pygame.event.get():
                    if event.type == pygame.QUIT:
                        running = False
                clock.tick(FPS)
                continue
            else:
                show_100_time = 0

        # Poziom 200 punktów - wygrana i ranking
        if punkty >= 200 and not wygrana:
            wygrana = True
            if winner_sound:
                winner_sound.play()
            show_win_time = pygame.time.get_ticks()
            continue
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            if event.type == pygame.MOUSEBUTTONDOWN:
                mx, my = pygame.mouse.get_pos()
                for s in samoloty:
                    # Sprawdź czy kliknięto guzik "Usuń" (przy każdym samolocie)
                    btn_rect = pygame.Rect(s.x, s.y + SAMOLOT_SIZE[1] + 5, 70, 30)
                    if btn_rect.collidepoint(mx, my):
                        if not s.bezpieczny:
                            punkty += 1
                            # Dźwięk powodzenia
                            if good_sound:
                                good_sound.play()
                        else:
                            punkty -= 1
                            # Dźwięk erroru
                            if error_sound:
                                error_sound.play()
                            else:
                                # Systemowy beep jeśli nie ma pliku
                                try:
                                    import winsound
                                    winsound.MessageBeep()
                                except:
                                    pass
                        samoloty.remove(s)
                        # Dodaj nowy samolot tylko jeśli nie przekroczono limitu
                        if len(samoloty) < liczba_samolotow(punkty):
                            samoloty.append(Samolot())
                        break

        # Sprawdź czy trzeba zwiększyć liczbę samolotów po zmianie poziomu
        docelowa_liczba = liczba_samolotow(punkty)
        while len(samoloty) < docelowa_liczba:
            samoloty.append(Samolot())
        while len(samoloty) > docelowa_liczba:
            samoloty.pop()
        # Aktualizacja
        for s in samoloty:
            s.update()
        # Rysowanie tła (zielono-białe)
        screen.fill((220, 255, 220))
        for i in range(0, display_width, 40):
            pygame.draw.line(screen, (200, 255, 200), (i, 0), (i, display_height), 2)
        for j in range(0, display_height, 40):
            pygame.draw.line(screen, (255, 255, 255), (0, j), (display_width, j), 2)
        # Lotnisko
        screen.blit(lotnisko_img, lotnisko_pos)
        # Samoloty
        for s in samoloty:
            s.draw(screen)
            opis = "Samolot bezpieczny" if s.bezpieczny else "Samolot NIEBEZPIECZNY"
            color = (0, 120, 0) if s.bezpieczny else (200, 0, 0)
            opis_surf = opis_font.render(opis, True, color)
            screen.blit(opis_surf, (s.x, s.y - 25))
            # Guzik "Usuń" przy każdym samolocie
            btn_rect = pygame.Rect(s.x, s.y + SAMOLOT_SIZE[1] + 5, 70, 30)
            pygame.draw.rect(screen, (255, 80, 80), btn_rect)
            btn_text = opis_font.render("Usuń", True, (255, 255, 255))
            screen.blit(btn_text, (s.x + 10, s.y + SAMOLOT_SIZE[1] + 10))
        # Punkty
        text = font.render(f"Punkty: {punkty}", True, (0, 0, 0))
        screen.blit(text, (10, 10))
        # Usunięto stary komunikat na 500 punktów
        pygame.display.flip()
        clock.tick(FPS)
    pygame.quit()
    sys.exit()

if __name__ == "__main__":
    main()
